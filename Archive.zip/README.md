# Start project local


```shell
cp .env.example .env
npm install
npm run start:dev


```

view openAPI on http://localhost:3001/docs/#/

