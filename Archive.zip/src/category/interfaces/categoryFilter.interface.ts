export interface CategoryFilter {
  search?: string;
  activated?: boolean;
}
