export interface ActivityFilter {
  search?: string;
  activated?: boolean;
}
