export const jwtConstants = {
  secret: 'secretKey',
  expiresIn: '300000s',
};
