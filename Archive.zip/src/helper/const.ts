export const zeroAddress = '0x0';
