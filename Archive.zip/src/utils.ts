export const isEmpty = (str: string): boolean => {
  return !str || str.length === 0;
};
