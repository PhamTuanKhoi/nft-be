export enum NftType {
  NORMAL = 'NORMAL',
  AUCTION = 'AUCTION',
  FORSALE = 'FORSALE',
}

export enum ActionType {
  BUY = 'BUY',
  AUCTION = 'AUCTION',
  FORSALE = 'FORSALE',
  BID = 'BID',
}
