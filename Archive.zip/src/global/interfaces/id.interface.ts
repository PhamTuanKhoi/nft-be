import { Schema } from 'mongoose';

export type ID = Schema.Types.ObjectId;
