export interface CollectionFilter {
  search?: string;
  activated?: boolean;
}
