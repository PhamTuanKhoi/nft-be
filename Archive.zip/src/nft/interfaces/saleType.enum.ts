export enum SaleType {
  FIXED = 0,
  AUCTION = 1,
}
