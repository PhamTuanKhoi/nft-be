export enum NftTypeEnum {
  OWNED = 'owned',
  CREATED = 'created',
  INSALE = 'insale',
}
