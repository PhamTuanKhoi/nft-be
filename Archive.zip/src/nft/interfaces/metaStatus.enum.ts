export enum MetaStatusEnum {
  READY = 0,
  PENDING = 1,
  MINTED = 2,
}
