export interface AttributeInterface {
  trai_type: string;
  value: string | number;
}
