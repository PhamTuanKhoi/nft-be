export interface ImageFilterInterface {
  search?: string;
}
