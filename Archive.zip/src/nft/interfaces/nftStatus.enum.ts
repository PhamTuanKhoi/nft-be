export enum NftStatusEnum {
  UPLOADED = 'uploaded',
  MINTED = 'minted',
  SOLD = 'sold',
}
