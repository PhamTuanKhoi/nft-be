import { TraitType } from './traitType.enum';
export interface TraitFilterInterface {
  search?: string;
  type?: TraitType;
}
