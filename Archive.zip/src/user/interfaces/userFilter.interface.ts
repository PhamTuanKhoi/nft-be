export interface UserFilter {
  search?: string;
  status?: string;
}
