export enum UserStatusEnum {
  ACTIVE = 'active',
  UNACTIVE = 'unactive',
}
