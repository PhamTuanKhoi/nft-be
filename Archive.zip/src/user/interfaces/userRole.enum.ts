export enum UserRoleEnum {
  ADMIN = 'admin',
  USER = 'user',
}
