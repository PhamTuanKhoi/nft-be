export interface TransactionFilterInterface {
  search?: string;
  // activated?: boolean;
  // status?: NftStatusEnum;
}
